function [alpha,fval,w,b]=svm(x,y,c)
%load ('q2_1_data.mat');


% x=trD;
% y=trLb;
% c=0.1;
[d,n]=size(x);
h=zeros(n,n);
f=-1*(ones(n,1));
A=[];
b=[];
Aeq=y';
beq=0;
lb=zeros(n,1);
ub=c*ones(n,1);
X = x'*x;
h = double((y *y'.*X));
[alpha, fval] = quadprog(h, f, A, b, Aeq, beq, lb, ub);
w=y.*alpha;
%disp(size(w));
%disp(size(alpha));
w=x*w;
%disp(alpha);


alpha_valid = alpha(alpha > 0.001 & c - alpha > 0.001);
index = alpha==alpha_valid(1);


b=y(index)-(w' * x(:, index));       
% disp(b)
% ypred=w'*valD+b;
% for i = 1:length(ypred)
%     if ypred(i) < 0
%         ypred(i) = -1;
%     else
%         ypred(i) = 1;
%     end
% end
% ypred=ypred';
% C = confusionmat(valLb,ypred);
% disp("confusion matrix")
% disp(C);
% disp(size(ypred));
% accuracy=sum(valLb==single(ypred))/length(valLb);
% disp("The accuracy is :")
% disp(accuracy*100);
% support_vectors=0;
% disp("The value of objective function is")
% disp(-1*fval)
% for i=1:n
%     if alpha(i)-0.001>0
%         support_vectors=support_vectors+1;
%     end
%  end
%  disp("number of suport vectors are")
%  disp(support_vectors)
% disp(size(x))
% disp(size(ub))
% disp(size(w))